public class Tyre {

}
